// Alerta de avaliação
const avaliacao = document.getElementById('chat');

avaliacao.addEventListener('click', () => {
  const resposta = confirm('Por que você ainda não consegue fazer o Download?Responda com "OK" para continuar.');
  if (resposta) {
    // Abra a URL em uma nova janela ou guia em branco
    window.open('https://www.youtube.com', '_blank');
  }
});


const checkbox = document. querySelector("#buttonAdd");
const p = document.getElementById('button__textAdd')



checkbox.addEventListener('mouseover',() => {
     
      p.innerText='+'
     
});
checkbox.addEventListener('mouseout', () => {
    p.innerText = 'Ver completo'; 
  });

// checkbox.addEventListener('click',() => {
//    p.//aqui que quero linkar
// });
// const urlRedirecionamento = 'https://acervolima.com';

// checkbox.addEventListener('click', () => {
//     // Redirecionar para a URL especificada
//     window.location.href = urlRedirecionamento;
// });


//   // Seleciona o elemento <a>
//   const aElement = document.querySelector("#buttonAdd a");
  
//   // Remove o elemento <button>
//   const buttonElement = document.getElementById("buttonAdd");
//   buttonElement.parentNode.removeChild(buttonElement);
  
//   // Adiciona o elemento <a> de volta ao documento
//   document.body.appendChild(aElement);
  
//   // Adiciona um evento de clique ao novo elemento <a>
//   aElement.addEventListener("click", function() {
//     // Redireciona para a URL do atributo "href" do elemento <a>
//     window.location.href = this.getAttribute("href");
//   });

