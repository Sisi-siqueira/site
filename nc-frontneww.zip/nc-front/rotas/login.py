from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.spinner import Spinner
from kivy.uix.popup import Popup

class LogApp(App):
    def build(self):
        self.theme()
        self.login_screen = self.create_login_screen()
        return self.login_screen

    def theme(self):
        # Defina aqui o tema do Kivy, se necessário.
        pass

    def create_login_screen(self):
        login_screen = BoxLayout(orientation="vertical", padding=10, spacing=10)

        # Imagem
        image = Label(text="Coloque sua imagem aqui")
        login_screen.add_widget(image)

        # Widgets de login
        username_input = TextInput(hint_text="Usuário")
        password_input = TextInput(hint_text="Senha", password=True)
        remember_toggle = ToggleButton(text="Lembrar senha")

        login_button = Button(text="Login", background_color=(1, 0.5, 0, 1))
        login_button.bind(on_press=self.login)

        login_screen.add_widget(username_input)
        login_screen.add_widget(password_input)
        login_screen.add_widget(remember_toggle)
        login_screen.add_widget(login_button)

        # Link para cadastro
        register_label = Label(text="_______________________________________________")
        login_screen.add_widget(register_label)

        register_button = Button(text="Cadastrar", background_color=(0, 0.5, 1, 1))
        register_button.bind(on_press=self.show_registration_popup)
        login_screen.add_widget(register_button)

        return login_screen

    def show_registration_popup(self, instance):
        # Crie a tela de cadastro aqui
        registration_popup = Popup(title="Cadastro")
        registration_popup.content = self.create_registration_screen(registration_popup.dismiss)
        registration_popup.open()

    def create_registration_screen(self, dismiss_callback):
        registration_screen = BoxLayout(orientation="vertical", padding=10, spacing=10)

        # Widgets de cadastro
        registration_label = Label(text="Coloque seus dados abaixo:")
        full_name_input = TextInput(hint_text="Nome completo:")
        day_input = TextInput(hint_text="Dia")
        month_spinner = Spinner(text="Janeiro", values=["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
                                                        "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"])
        year_input = TextInput(hint_text="Ano")
        class_spinner = Spinner(text="Turma", values=["1°", "2°", "3°"])
        shift_spinner = Spinner(text="Turno", values=["Manhã", "Tarde", "Noite"])
        gender_spinner = Spinner(text="Sexo", values=["Homem", "Mulher", "Prefiro não dizer"])

        registration_screen.add_widget(registration_label)
        registration_screen.add_widget(full_name_input)
        registration_screen.add_widget(day_input)
        registration_screen.add_widget(month_spinner)
        registration_screen.add_widget(year_input)
        registration_screen.add_widget(class_spinner)
        registration_screen.add_widget(shift_spinner)
        registration_screen.add_widget(gender_spinner)

        registration_label2 = Label(text="__________________________________________")
        registration_screen.add_widget(registration_label2)

        back_button = Button(text="Voltar", background_color=(0.5, 0.5, 0.5, 1))
        back_button.bind(on_press=dismiss_callback)
        registration_screen.add_widget(back_button)

        next_button = Button(text="Próximo", background_color=(1, 0.5, 0, 1))
        # Defina a função de callback para passar para a próxima etapa do cadastro
        # Exemplo: next_button.bind(on_press=self.next_registration_step)
        registration_screen.add_widget(next_button)

        return registration_screen

    def login(self, instance):
        # Implemente aqui a lógica de login
        pass

    # Adicione a função para a próxima etapa do cadastro, se necessário
    # def next_registration_step(self, instance):
    #     pass

if __name__ == "__main__":
    LogApp().run()
