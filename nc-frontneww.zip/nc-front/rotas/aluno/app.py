from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label


class MainApp(App):
    def build(self):
        self.theme()
        self.tela()
        self.tela_apos_login()

    def theme(self):
        # Defina aqui o tema do Kivy, se necessário.
        pass

    def tela(self):
        self.root = BoxLayout(orientation="vertical", padding=10, spacing=10, size_hint=(None, None), size=(300, 500))
        self.root.add_widget(Label(text="Bem-vindo ao Neo Class", size_hint_y=None, height=50))

    def tela_apos_login(self):
        inicio_frame = BoxLayout(orientation="vertical", padding=10, spacing=10, size_hint=(None, None),
                                 size=(300, 500))
        inicio_frame.add_widget(Label(text="conteudo", size_hint_y=None, height=50))
        self.root.add_widget(inicio_frame)




if __name__ == "__main__":
    MainApp().run()
